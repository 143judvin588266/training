package com.mortgage;

public interface MortgageReportDisplay {
    void printMortgage();

    void printPaymentSchedule();
}
