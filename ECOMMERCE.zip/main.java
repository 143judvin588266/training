package com.product;

public class Main {

    public static void main(String[] args) {
	// write your code here
//        ProductFilter pf = new ProductFilter();
//        pf.displayAll();
        Console c = new Console();
        c.readInput();
    }
}