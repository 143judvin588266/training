package com.product;

public interface ProductDisplay {
    void displayAll();

    void displayCategory(Category category);
}