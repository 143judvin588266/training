package com.product;

import java.util.List;

public class ProductFilter extends Product implements ProductDisplay {

    public ProductFilter(){}
    public ProductFilter(String name, String brand, double price, float rating, Category category) {
        super(name, brand, price, rating, category);
    }

    private static List<Product> products = List.of(
       new Product("One Plus 8T","One Plus",30000,4.0f,Category.MOBILES),
            new Product("Oppo f20","samsung",20000,3.5f,Category.MOBILES),
            new Product("HTC M8","lenovo",18000,2.8f,Category.MOBILES),
            new Product("Macbook Pro","Apple",60000,5,Category.LAPTOPS),
            new Product("dell Vivobook 14","dell",40000,3,Category.LAPTOPS),

            new Product("Adidas","Adidas",8000,4,Category.SHOES),
            new Product("fasttrack","Fastrack",2000,2,Category.SHOEES),
            new Product("puma","puma",5000,3,Category.SHOES),

            new Product("laptop bag","dell",4000,3,Category.BAGS),
            new Product("backpack","nsign",2000,4,Category.BAGS),
        

    );





    @Override
    public void displayAll(){
        products.stream()
                .forEach(p -> System.out.println("Name: " + p.getName() + "   Brand: " + p.getBrand() + "   Price: " + p.getPrice() + "   Rating: " + p.getRating()));
    }


    @Override
    public void displayCategory(Category category){
        products.stream()
                .filter(p -> p.getCategory() == category)
                .forEach(p -> System.out.println("Name: " + p.getName() + "   Brand: " + p.getBrand() + "   Price: " + p.getPrice() + "   Rating: " + p.getRating()));
    }



}
