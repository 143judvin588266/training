package com.product;

public enum Category {
    MOBILES,
    LAPTOPS,
    SHOES,
    BAGS
}
